# HeliStabilityKithack

This repository contains the early structure for the Heli Stability System for KitHack Model Club.

Uploaded files:
- `src/HeliTuningLabPlugin.cs`
- `src/RBInvestigation.cs`

MIT licensed.
